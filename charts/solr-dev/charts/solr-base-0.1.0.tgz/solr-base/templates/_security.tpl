{{/*
Security resources: security.json ConfigMap and basic-auth Secret for the Solr Operator.
*/}}

{{/*
ConfigMap containing security.json for Solr basic auth.
This is uploaded to ZooKeeper by the setup Job before Solr starts reading it.
*/}}
{{- define "solr-base.securityConfigMap" -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "solr-base.fullname" . }}-security
  namespace: {{ include "solr-base.namespace" . }}
  labels:
    {{- include "solr-base.labels" . | nindent 4 }}
data:
  security.json: |
    {
      "authentication": {
        "class": "solr.BasicAuthPlugin",
        "blockUnknown": false,
        "forwardCredentials": false,
        "credentials": {
          "admin": "{{ .Values.solr.auth.adminPasswordHash }}",
          "solr": "{{ .Values.solr.auth.solrPasswordHash }}",
          "k8s-oper": "{{ .Values.solr.auth.operPasswordHash }}"
        }
      },
      "authorization": {
        "class": "solr.RuleBasedAuthorizationPlugin",
        "user-role": {
          "admin": ["admin"],
          "solr": ["reader"],
          "k8s-oper": ["admin"]
        },
        "permissions": [
          {
            "name": "security-edit",
            "role": "admin"
          },
          {
            "name": "security-read",
            "role": "admin"
          },
          {
            "name": "schema-edit",
            "role": "admin"
          },
          {
            "name": "schema-read",
            "role": ["admin", "reader"]
          },
          {
            "name": "config-edit",
            "role": "admin"
          },
          {
            "name": "config-read",
            "role": ["admin", "reader"]
          },
          {
            "name": "collection-admin-edit",
            "role": "admin"
          },
          {
            "name": "collection-admin-read",
            "role": ["admin", "reader"]
          },
          {
            "name": "core-admin-edit",
            "role": "admin"
          },
          {
            "name": "core-admin-read",
            "role": ["admin", "reader"]
          },
          {
            "name": "update",
            "role": "admin"
          },
          {
            "name": "read",
            "role": ["admin", "reader"]
          },
          {
            "name": "all",
            "role": "admin"
          }
        ]
      }
    }
{{- end }}

{{/*
Secret containing basic-auth credentials for the Solr Operator.
The operator uses this to communicate with Solr for health checks and management.
*/}}
{{- define "solr-base.basicAuthSecret" -}}
apiVersion: v1
kind: Secret
metadata:
  name: {{ include "solr-base.solrcloudName" . }}-solrcloud-basic-auth
  namespace: {{ include "solr-base.namespace" . }}
  labels:
    {{- include "solr-base.labels" . | nindent 4 }}
type: kubernetes.io/basic-auth
stringData:
  username: k8s-oper
  password: {{ .Values.solr.auth.operPassword | quote }}
{{- end }}
