{{/*
Kubernetes Job that uploads configsets to ZooKeeper and creates collections
in Solr. Runs once after both ZK and SolrCloud are deployed.

The Job uses the solr:8.11.2 image which includes the `solr zk` CLI and curl.
*/}}

{{- define "solr-base.setupJob" -}}
apiVersion: batch/v1
kind: Job
metadata:
  name: {{ include "solr-base.fullname" . }}-setup
  namespace: {{ include "solr-base.namespace" . }}
  labels:
    {{- include "solr-base.labels" . | nindent 4 }}
    app.kubernetes.io/component: setup
  annotations:
    # Allow re-running: delete the old Job first, then helm upgrade
    helm.sh/hook-delete-policy: before-hook-creation
spec:
  backoffLimit: 5
  ttlSecondsAfterFinished: 300
  template:
    metadata:
      labels:
        {{- include "solr-base.labels" . | nindent 8 }}
        app.kubernetes.io/component: setup
    spec:
      restartPolicy: OnFailure
      containers:
        - name: setup
          image: "{{ .Values.setupJob.image.repository }}:{{ .Values.setupJob.image.tag }}"
          command: ["/bin/bash", "/scripts/setup.sh"]
          env:
            - name: ZK_HOST
              value: {{ include "solr-base.zkConnectionString" . | quote }}
            - name: SOLR_HOST
              value: "http://{{ include "solr-base.solrcloudName" . }}-solrcloud-common"
            - name: SOLR_ADMIN_USER
              value: "admin"
            - name: SOLR_ADMIN_PASSWORD
              value: {{ .Values.solr.auth.adminPassword | quote }}
            - name: REPLICA_OVERRIDE
              value: {{ .Values.collections.replicaOverride | quote }}
            - name: CONFIGSETS_DIR
              value: "/configsets"
            - name: COLLECTIONS_FILE
              value: "/collections/collections.yml"
          volumeMounts:
            - name: setup-script
              mountPath: /scripts
              readOnly: true
            - name: security-json
              mountPath: /security
              readOnly: true
            - name: collections
              mountPath: /collections
              readOnly: true
            {{- range .Values.configsetNames }}
            - name: configset-{{ . }}
              mountPath: /configsets/{{ . }}/conf
              readOnly: true
            {{- end }}
      volumes:
        - name: setup-script
          configMap:
            name: {{ include "solr-base.fullname" . }}-setup-script
            defaultMode: 0755
        - name: security-json
          configMap:
            name: {{ include "solr-base.fullname" . }}-security
        - name: collections
          configMap:
            name: {{ include "solr-base.fullname" . }}-collections
        {{- range .Values.configsetNames }}
        - name: configset-{{ . }}
          configMap:
            name: {{ include "solr-base.fullname" $ }}-configset-{{ . }}
        {{- end }}
{{- end }}

{{/*
ConfigMap containing the setup.sh script.
*/}}
{{- define "solr-base.setupScriptConfigMap" -}}
apiVersion: v1
kind: ConfigMap
metadata:
  name: {{ include "solr-base.fullname" . }}-setup-script
  namespace: {{ include "solr-base.namespace" . }}
  labels:
    {{- include "solr-base.labels" . | nindent 4 }}
data:
  setup.sh: |
    {{- .Files.Get "scripts/setup.sh" | nindent 4 }}
{{- end }}
